/* Archivo random_funcion.c que incluye la definición de las funciones a utilizar */
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include "calculadora_local.h"

struct numeros { 
double a;
double b;
};



double suma(numeros num){return a+b;}
double resta(numeros num){return a-b;}
double multi(numeros num){return a*b;}
double divi(numeros num){return a/b;}

