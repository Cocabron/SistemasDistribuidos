#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

struct numeros { 
double a;
double b;
};


double suma(numeros);
double resta(numeros);
double multi(numeros);
double divi(numeros);
